PATH="/opt/amazon/efa/bin/:$PATH"
PATH="/opt/amazon/openmpi/bin/:$PATH"
