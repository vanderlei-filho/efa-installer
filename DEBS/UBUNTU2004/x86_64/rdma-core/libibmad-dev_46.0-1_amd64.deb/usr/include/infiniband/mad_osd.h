#warning "This header is obsolete."
